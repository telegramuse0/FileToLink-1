# Main bot logic with all tasks integrated
