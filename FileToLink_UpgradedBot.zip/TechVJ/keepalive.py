# ping_server and clean_temp_files task
