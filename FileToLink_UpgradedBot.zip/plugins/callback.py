# Handlers for help/about inline buttons
