# /users command to list all users
