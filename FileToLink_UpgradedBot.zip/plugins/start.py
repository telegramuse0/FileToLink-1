# Enhanced /start handler with db.add_user and inline buttons
