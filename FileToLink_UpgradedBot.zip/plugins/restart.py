# /restart command for admin
