# /admin command with buttons
